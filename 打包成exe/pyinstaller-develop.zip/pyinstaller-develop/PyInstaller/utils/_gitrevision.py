#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "8c27d2668c"     # abbreviated commit hash
commit = "8c27d2668cb9dea14302a0cffffb7dd997574ee1"  # commit hash
date = "2019-03-08 08:34:12 +0100"   # commit date
author = "Tobias V. Langhoff <tobias@langhoff.no>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Doc: Fix typo.

"""
